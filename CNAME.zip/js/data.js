// js/data.js
export async function loadTechTreeData() {
   // TODO: Replace with your actual data loading logic
   // For now, returning some sample data
   return {
       Atreides: { 
           // Sample tech tree data for Atreides
       },
       // ... data for other houses
   };
}